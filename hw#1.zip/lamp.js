var power = false;

function turn(){
    if(power){
        power=false;
    }
    else{
        power=true;
    }
}

var power = false;
var cur_temp = 50;
var target_temp = 24;

function control_temp(){
    if (cur_temp>target_temp){
        for(i=cur_temp;i<target_temp;i--){
        }
        cur_temp=i;
        console.log("beep!")
    }
    else if (cur_temp<target_temp){
        for(i=cur_temp;i<target_temp;i++){
        }
        console.log("beep!")
    }
}
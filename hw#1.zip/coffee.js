var max_water = 200;
var max_bean = 50;
var cur_water = 100;
var cur_bean = 30;
var power = false;
var coffee{

};

function make_coffee(){ 
    if(power == TURE){
        if (cur_water > 5 && cur_coffee >3 ){
            //coffee -3, water -5
            //make coffee
            //complete alert
        }
        else {
            //alert
        }
    }
    else{
        //alert ('turn on!')
    }
    
}
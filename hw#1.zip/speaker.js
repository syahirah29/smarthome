var power = false;
var morning = 0900;

function app_alert(app_log){
    console.log(app_log);
}

function moring_alart(current_time){
    if(moring_time==current_time){
        console.log("Wake UP!");
    }
}



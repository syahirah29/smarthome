var smarthome = require('./tv1.js');
console.log(smarthome)
var cc = smarthome.goto_next_channel();
console.log(cc);